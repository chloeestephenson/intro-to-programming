/* 
Chloee
9/27/18
Exercise 1-13
*/

class Exercise113 {
	public static void main(String[] args) {
		double a, b, c, d, e, f;
			a = 3.4;
			b = 50.2;
			c = 2.1;
			d = 0.55;
			e = 44.5;
			f = 5.9;
		System.out.print("x = ");
		System.out.println((e * d - b * f) / (a * d - b * c));
		System.out.print("y = ");
		System.out.print((a * f - e * c) / (a * d - b * c));
	}
}