/* 
	Author: Chloee
	Date: 9/21/18
	Description: HelloWorld
*/
public class HelloWorld
{
	public static void main(String[] args)
	{
		System.out.print("Hello, World");
	}
	
}
