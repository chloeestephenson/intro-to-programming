/* 
	Author: Chloee
	Date: 9/21/18
	Description: Math
*/
class example_1_5 {
	public static void main(String[] args) 
	{
		System.out.print((9.5 * 4.5 - 2.5 * 3)/45.5 - 3.5);
		
	}
}