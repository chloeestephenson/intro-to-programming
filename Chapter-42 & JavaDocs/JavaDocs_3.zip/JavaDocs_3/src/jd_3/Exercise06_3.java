/*
Author: Chloee Stephenson 
Date: 12/17/18
Description: Is this number a palindrome or not.
*/
package jd_3;

import java.util.Scanner;

/**
 * <h1> JavaDoc Test </h1>
 * <p> This class returns yes if the entered number is a palindrome</p>
 * 
 * <a href="https://goo.gl/fr8PHb"> Click here for more information on JavaDocs</a>
 * 
 * <p> Created: 1/22/19</p>
 * 
 * @author Chloee Stephenson
 *
 */

public class Exercise06_3 {
	/**
	 * This method is used to determine 
	 * if the entered number is a palindrome by calling the 
	 * isPalindrome() method.
	 * 
	 * @param args - argument from console; unused
	 */
    public static void main(String args[]){
     
        System.out.println("Please Enter a number : ");
        int palindrome = new Scanner(System.in).nextInt();

        if(isPalindrome(palindrome)){
            System.out.println("Number : " + palindrome + " is a palindrome");
        }else{
            System.out.println("Number : " + palindrome + " is not a palindrome");
        }       
        
    }
  /**
   * This method is used to return the palindrome if it is decided true in the previous method
   * 
   * @param number - int; number being tested
   * @return - returns boolean; if true then number is a palindrome
   */
    public static boolean isPalindrome(int number) {
        int palindrome = number; 
        int reverse = 0;
        
        while (palindrome != 0) {
            int remainder = palindrome % 10;
            reverse = reverse * 10 + remainder;
            palindrome = palindrome / 10;
        }

        if (number == reverse) {
            return true;
        }
        return false;
    }

}





