package ch42_37;

import static org.junit.Assert.*;

import org.junit.Test;

public class Exercise6_37Test {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
